package pl.mandzukuo.mandzukuosmp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

public class MandzukuoSMP extends JavaPlugin implements Listener {

    private String prefix;
    private String mainWorld;
    private int guiSize;

    private Economy economy;
    private Prices prices;
    private ShopGUI shopGUI;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.prefix = color(getConfig().getString("prefix", "&6[MandzukuoSMP]&f "));
        this.mainWorld = getConfig().getString("main_world", "MandzukuoSMP");
        this.guiSize = getConfig().getInt("gui_size", 54);

        saveResourceIfMissing("prices.yml");
        saveResourceIfMissing("balances.yml");

        this.economy = new Economy(this);
        this.prices = new Prices(this);
        this.shopGUI = new ShopGUI(this);

        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("MandzukuoSMP v1.0 wlaczony.");
    }

    @Override
    public void onDisable() {
        if (economy != null) economy.save();
        getLogger().info("MandzukuoSMP v1.0 wylaczony.");
    }

    private void saveResourceIfMissing(String name) {
        File f = new File(getDataFolder(), name);
        if (!f.exists()) {
            saveResource(name, false);
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("sklep")) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage(prefix + color("&cTylko dla graczy."));
                return true;
            }
            if (!isInMainWorld(p.getWorld())) {
                p.sendMessage(prefix + color("&cSklep jest niedostępny w tym trybie!"));
                return true;
            }
            shopGUI.openBuy(p);
            return true;
        }

        if (command.getName().equalsIgnoreCase("mandzukuo")) {
            if (!sender.hasPermission("mandzukuo.admin")) {
                sender.sendMessage(prefix + color("&cBrak uprawnień."));
                return true;
            }
            if (args.length == 0) {
                sender.sendMessage(color("&eUżycie: /mandzukuo <reload|sklep-tryb <świat>>"));
                return true;
            }
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "reload":
                    reloadConfig();
                    this.prefix = color(getConfig().getString("prefix", "&6[MandzukuoSMP]&f "));
                    this.mainWorld = getConfig().getString("main_world", "MandzukuoSMP");
                    this.guiSize = getConfig().getInt("gui_size", 54);
                    this.prices.reload();
                    this.shopGUI.rebuildInventories();
                    sender.sendMessage(prefix + color("&aPrzeładowano konfigurację i ceny."));
                    break;
                case "sklep-tryb":
                    if (args.length < 2) {
                        sender.sendMessage(color("&eUżycie: /mandzukuo sklep-tryb <świat>"));
                        return true;
                    }
                    this.mainWorld = args[1];
                    getConfig().set("main_world", this.mainWorld);
                    saveConfig();
                    sender.sendMessage(prefix + color("&aUstawiono tryb sklepu na świat: &f") + this.mainWorld);
                    break;
                default:
                    sender.sendMessage(color("&eNieznana komenda."));
            }
            return true;
        }

        return false;
    }

    private boolean isInMainWorld(World world) {
        return world != null && world.getName().equalsIgnoreCase(this.mainWorld);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Inventory inv = e.getInventory();
        InventoryHolder holder = inv.getHolder();
        if (!(holder instanceof ShopHolder)) return;

        e.setCancelled(true);
        ShopHolder shopHolder = (ShopHolder) holder;
        int slot = e.getRawSlot();

        if (slot == 0) { shopGUI.openBuy(p); return; }
        if (slot == 8) { shopGUI.openSell(p); return; }
        if (slot >= inv.getSize()) return;

        if (shopHolder.page == ShopPage.BUY) {
            ShopItem si = prices.bySlot.get(slot);
            if (si == null || si.buyPrice.compareTo(BigDecimal.ZERO) <= 0) return;

            BigDecimal price = si.buyPrice;
            String world = p.getWorld().getName();
            if (economy.getBalance(p, world).compareTo(price) < 0) {
                p.sendMessage(prefix + color("&cNie masz wystarczających środków. Cena: &f$" + fmt(price)));
                return;
            }
            ItemStack product = new ItemStack(si.material, 1);
            java.util.HashMap<Integer, ItemStack> leftovers = p.getInventory().addItem(product);
            if (!leftovers.isEmpty()) {
                p.sendMessage(prefix + color("&cMasz pełny ekwipunek."));
                return;
            }
            economy.withdraw(p, world, price);
            p.sendMessage(prefix + color("&aKupiono &f1x ") + nice(si.material.name()) + color(" &aza &f$" + fmt(price) + "&a. Saldo: &f$" + fmt(economy.getBalance(p, world))));
        } else if (shopHolder.page == ShopPage.SELL) {
            ShopItem si = prices.bySlot.get(slot);
            if (si == null || si.sellPrice.compareTo(BigDecimal.ZERO) <= 0) return;

            boolean shift = e.isShiftClick();
            String world = p.getWorld().getName();

            if (shift) {
                int totalSold = 0;
                ItemStack[] contents = p.getInventory().getContents();
                for (int i = 0; i < contents.length; i++) {
                    ItemStack it = contents[i];
                    if (it == null || it.getType() != si.material) continue;
                    totalSold += it.getAmount();
                    contents[i] = null;
                }
                p.getInventory().setContents(contents);
                if (totalSold == 0) {
                    p.sendMessage(prefix + color("&eNie masz żadnych przedmiotów typu ") + nice(si.material.name()) + color(" do sprzedaży."));
                    return;
                }
                BigDecimal total = si.sellPrice.multiply(new BigDecimal(totalSold));
                economy.deposit(p, world, total);
                p.sendMessage(prefix + color("&aSprzedano &f") + totalSold + "x " + nice(si.material.name())
                        + color(" &aza &f$" + fmt(total) + "&a. Saldo: &f$" + fmt(economy.getBalance(p, world))));
            } else {
                if (!p.getInventory().contains(si.material)) {
                    p.sendMessage(prefix + color("&eNie masz tego przedmiotu w ekwipunku."));
                    return;
                }
                p.getInventory().removeItem(new ItemStack(si.material, 1));
                economy.deposit(p, world, si.sellPrice);
                p.sendMessage(prefix + color("&aSprzedano &f1x ") + nice(si.material.name())
                        + color(" &aza &f$" + fmt(si.sellPrice) + "&a. Saldo: &f$" + fmt(economy.getBalance(p, world))));
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent e) {}

    private static class ShopHolder implements InventoryHolder {
        final ShopPage page;
        ShopHolder(ShopPage page) { this.page = page; }
        @Override public Inventory getInventory() { return null; }
    }
    private enum ShopPage { BUY, SELL }

    private class ShopGUI {
        private Inventory buyInv;
        private Inventory sellInv;

        ShopGUI(MandzukuoSMP plugin) {
            rebuildInventories();
        }

        void rebuildInventories() {
            this.buyInv = Bukkit.createInventory(new ShopHolder(ShopPage.BUY), guiSize, color("&6Sklep &7• &aKupno"));
            this.sellInv = Bukkit.createInventory(new ShopHolder(ShopPage.SELL), guiSize, color("&6Sklep &7• &cSprzedaż"));
            buildTabs(buyInv, ShopPage.BUY);
            buildTabs(sellInv, ShopPage.SELL);

            for (ShopItem si : prices.items) {
                if (si.slot < 9 || si.slot >= guiSize) continue;
                ItemStack buyIcon = new ItemStack(si.material);
                ItemMeta bm = buyIcon.getItemMeta();
                bm.setDisplayName(color(si.name != null ? si.name : "&f" + nice(si.material.name())));
                bm.setLore(java.util.Arrays.asList(
                        color("&7Cena kupna: &f$" + fmt(si.buyPrice)),
                        color("&8Kliknij: &7kup 1 szt.")
                ));
                bm.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
                buyIcon.setItemMeta(bm);
                buyInv.setItem(si.slot, buyIcon);

                ItemStack sellIcon = new ItemStack(si.material);
                ItemMeta sm = sellIcon.getItemMeta();
                sm.setDisplayName(color(si.name != null ? si.name : "&f" + nice(si.material.name())));
                sm.setLore(java.util.Arrays.asList(
                        color("&7Cena sprzedaży: &f$" + fmt(si.sellPrice)),
                        color("&8Kliknij: &7sprzedaj 1"),
                        color("&8Shift+klik: &7sprzedaj wszystko z ekwipunku")
                ));
                sm.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
                sellIcon.setItemMeta(sm);
                sellInv.setItem(si.slot, sellIcon);
            }
        }

        private void buildTabs(Inventory inv, ShopPage active) {
            ItemStack buy = new ItemStack(Material.LIME_STAINED_GLASS_PANE);
            ItemMeta bm = buy.getItemMeta();
            bm.setDisplayName(color(active == ShopPage.BUY ? "&a&lKupno (aktywne)" : "&aKupno"));
            buy.setItemMeta(bm);

            ItemStack sell = new ItemStack(Material.RED_STAINED_GLASS_PANE);
            ItemMeta sm = sell.getItemMeta();
            sm.setDisplayName(color(active == ShopPage.SELL ? "&c&lSprzedaż (aktywne)" : "&cSprzedaż"));
            sell.setItemMeta(sm);

            inv.setItem(0, buy);
            inv.setItem(8, sell);
        }

        void openBuy(Player p) { p.openInventory(buyInv); }
        void openSell(Player p) { p.openInventory(sellInv); }
    }

    private static class ShopItem {
        final String key;
        final String name;
        final Material material;
        final BigDecimal buyPrice;
        final BigDecimal sellPrice;
        final int slot;

        ShopItem(String key, String name, Material material, BigDecimal buyPrice, BigDecimal sellPrice, int slot) {
            this.key = key;
            this.name = name;
            this.material = material;
            this.buyPrice = buyPrice.setScale(2, RoundingMode.HALF_UP);
            this.sellPrice = sellPrice.setScale(2, RoundingMode.HALF_UP);
            this.slot = slot;
        }
    }

    private class Prices {
        private final MandzukuoSMP plugin;
        private final File file;
        private FileConfiguration cfg;
        final java.util.List<ShopItem> items = new java.util.ArrayList<>();
        final java.util.Map<Integer, ShopItem> bySlot = new java.util.HashMap<>();

        Prices(MandzukuoSMP plugin) {
            this.plugin = plugin;
            this.file = new File(plugin.getDataFolder(), "prices.yml");
            reload();
        }

        void reload() {
            this.cfg = new YamlConfiguration();
            try { cfg.load(file); } catch (IOException | InvalidConfigurationException e) {
                plugin.getLogger().severe("Nie mozna zaladowac prices.yml: " + e.getMessage());
            }
            items.clear();
            bySlot.clear();
            if (!cfg.isConfigurationSection("items")) return;
            for (String key : cfg.getConfigurationSection("items").getKeys(false)) {
                String base = "items." + key + ".";
                String name = cfg.getString(base + "name", null);
                String matName = cfg.getString(base + "material", "STONE").toUpperCase(java.util.Locale.ROOT);
                Material mat;
                try { mat = Material.valueOf(matName); } catch (Exception ex) { plugin.getLogger().warning("Zly material przy " + key + ": " + matName); continue; }
                BigDecimal buy = new BigDecimal(String.valueOf(cfg.getDouble(base + "buy", 0.0)));
                BigDecimal sell = new BigDecimal(String.valueOf(cfg.getDouble(base + "sell", 0.0)));
                int slot = cfg.getInt(base + "slot", -1);
                ShopItem si = new ShopItem(key, name, mat, buy, sell, slot);
                items.add(si);
                bySlot.put(slot, si);
            }
        }
    }

    private class Economy {
        private final MandzukuoSMP plugin;
        private final File file;
        private final FileConfiguration cfg;
        private final java.util.Map<UUID, java.util.Map<String, BigDecimal>> balances = new java.util.HashMap<>();

        Economy(MandzukuoSMP plugin) {
            this.plugin = plugin;
            this.file = new File(plugin.getDataFolder(), "balances.yml");
            this.cfg = new YamlConfiguration();
            try {
                this.cfg.load(file);
            } catch (IOException | InvalidConfigurationException e) {
                plugin.getLogger().warning("Brak balances.yml – tworze nowy.");
            }
            load();
        }

        private void load() {
            balances.clear();
            for (String uuidStr : cfg.getKeys(false)) {
                UUID uuid;
                try { uuid = UUID.fromString(uuidStr); }
                catch (Exception e) { continue; }
                java.util.Map<String, BigDecimal> map = new java.util.HashMap<>();
                for (String world : cfg.getConfigurationSection(uuidStr).getKeys(false)) {
                    String val = String.valueOf(cfg.get(uuidStr + "." + world));
                    try {
                        map.put(world, new BigDecimal(val).setScale(2, RoundingMode.HALF_UP));
                    } catch (Exception ex) {
                        map.put(world, BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP));
                    }
                }
                balances.put(uuid, map);
            }
        }

        void save() {
            FileConfiguration out = new YamlConfiguration();
            for (java.util.Map.Entry<UUID, java.util.Map<String, BigDecimal>> e : balances.entrySet()) {
                for (java.util.Map.Entry<String, BigDecimal> w : e.getValue().entrySet()) {
                    out.set(e.getKey().toString() + "." + w.getKey(), w.getValue().toPlainString());
                }
            }
            try { out.save(file); } catch (IOException e) { plugin.getLogger().severe("Nie moge zapisac balances.yml: " + e.getMessage()); }
        }

        BigDecimal getBalance(Player p, String world) {
            balances.putIfAbsent(p.getUniqueId(), new java.util.HashMap<>());
            java.util.Map<String, BigDecimal> perWorld = balances.get(p.getUniqueId());
            perWorld.putIfAbsent(world, BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP));
            return perWorld.get(world);
        }

        void deposit(Player p, String world, BigDecimal amount) {
            java.util.Map<String, BigDecimal> perWorld = balances.computeIfAbsent(p.getUniqueId(), k -> new java.util.HashMap<>());
            BigDecimal cur = perWorld.getOrDefault(world, BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP));
            perWorld.put(world, cur.add(amount).setScale(2, RoundingMode.HALF_UP));
            save();
        }

        void withdraw(Player p, String world, BigDecimal amount) {
            java.util.Map<String, BigDecimal> perWorld = balances.computeIfAbsent(p.getUniqueId(), k -> new java.util.HashMap<>());
            BigDecimal cur = perWorld.getOrDefault(world, BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP));
            perWorld.put(world, cur.subtract(amount).setScale(2, RoundingMode.HALF_UP));
            save();
        }
    }

    private static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }
    private static String fmt(BigDecimal bd) { return bd.setScale(2, RoundingMode.HALF_UP).toPlainString(); }
    private static String nice(String matName) {
        return java.util.Arrays.stream(matName.toLowerCase(java.util.Locale.ROOT).split("_"))
                .map(w -> w.substring(0,1).toUpperCase(java.util.Locale.ROOT) + w.substring(1))
                .collect(Collectors.joining(" "));
    }
}
