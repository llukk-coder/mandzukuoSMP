# MandzukuoSMP v1.0

- Komenda `/sklep` z zakładkami **Kupno/Sprzedaż**
- Shift+klik w zakładce sprzedaży = sprzedaj cały ekwipunek danego typu
- Własna ekonomia per-świat (`balances.yml`)
- `prices.yml` trzyma ceny + **sloty GUI** (0..8 to zakładki, itemy od 9)

## Build lokalnie
```bash
mvn package
# target/MandzukuoSMPv1.0.jar
```

## Build przez GitHub Actions
- Zostaw `.github/workflows/build.yml` w repo
- Uruchom workflow **build** w zakładce Actions
- Pobierz artefakt **MandzukuoSMPv1.0.jar**
